# Counter-Up-Timer
Count Up Timer - Using Vanilla JS ( Mostly ) and Jquery 
<hr>
Features :
<ul type="square">
   <li>Counter stay on even URL changes  </li>
   <li>Have Ajax method pre-made for storing time data </li>
   <li>This counter uses local storage of a broswer so no delay </li>
   <li>Notification animation added here</li>
</ul>
<hr>
Depandecies :
<ul type="square">
   <li>Bootstrap 4.6  </li>
   <li>Jquery 3.5 </li>
</ul>
Live Preview : <a href="https://tahsin-ahmed52225.github.io/Counter-Up-Timer/"> Click Here </a> 
